<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class API extends CI_Controller {

function __construct(){
parent::__construct();
// load the employee model
$this->load->model('RestService');
}

	public function index()
	{
         $this->load->view('restview');
       
		//$this->load->view('restview');
        
	}
      //show function
    public function show()
    {
      //  $this->load->helper(‘url’); 
                
       
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */